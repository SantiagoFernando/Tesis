CREATE DATABASE IF NOT EXISTS `dbprestamos`;

USE `dbprestamos`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `categoria`;

CREATE TABLE `categoria` (
  `idcategoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombrecategoria` varchar(100) NOT NULL,
  `estadocategoria` varchar(45) NOT NULL,
  PRIMARY KEY (`idcategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `categoria` VALUES (1,"PORTATIL","A"),
(2,"PROYECTOR","A"),
(3,"PARLANTES","A"),
(4,"COMPUTADORA ESCRITORIO","A");


DROP TABLE IF EXISTS `cuenta`;

CREATE TABLE `cuenta` (
  `idcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` int(11) NOT NULL,
  `clave` varchar(45) NOT NULL,
  `estadocuenta` varchar(45) NOT NULL,
  `personaid` int(11) NOT NULL,
  PRIMARY KEY (`idcuenta`),
  KEY `FK_cuenta_persona` (`personaid`),
  CONSTRAINT `FK_cuenta_persona` FOREIGN KEY (`personaid`) REFERENCES `persona` (`idpersona`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `cuenta` VALUES (1,1105153801,"40bd001563085fc35165329ea1ff5c5ecbdbbeef","A",1),
(2,1150314183,"da39a3ee5e6b4b0d3255bfef95601890afd80709","A",2),
(3,1104334634,"da39a3ee5e6b4b0d3255bfef95601890afd80709","A",4);


DROP TABLE IF EXISTS `detalleprestamo`;

CREATE TABLE `detalleprestamo` (
  `iddetalle` int(11) NOT NULL,
  `categoria` varchar(100) NOT NULL,
  `numeroequipo` int(11) NOT NULL,
  `equipoid` int(11) NOT NULL,
  KEY `FK_detalle_prestamo` (`iddetalle`),
  KEY `FK_detalle_equipo` (`equipoid`),
  CONSTRAINT `FK_detalle_equipo` FOREIGN KEY (`equipoid`) REFERENCES `equipo` (`idequipo`),
  CONSTRAINT `FK_detalle_prestamo` FOREIGN KEY (`iddetalle`) REFERENCES `prestamo` (`idprestamo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `detalleprestamo` VALUES (1,"PORTATIL",3,3),
(1,"PROYECTOR",2,2);


DROP TABLE IF EXISTS `devolucion`;

CREATE TABLE `devolucion` (
  `iddevolucion` int(11) NOT NULL AUTO_INCREMENT,
  `fechadevolucion` date NOT NULL,
  `observacion` varchar(500) NOT NULL,
  `prestamoid` int(11) NOT NULL,
  PRIMARY KEY (`iddevolucion`),
  KEY `FK_devolucion_prestamo` (`prestamoid`),
  CONSTRAINT `FK_devolucion_prestamo` FOREIGN KEY (`prestamoid`) REFERENCES `prestamo` (`idprestamo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `equipo`;

CREATE TABLE `equipo` (
  `idequipo` int(11) NOT NULL AUTO_INCREMENT,
  `adquisicion` varchar(100) NOT NULL,
  `serie` int(11) NOT NULL,
  `marca` varchar(45) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `numero` int(11) NOT NULL,
  `ubicacion` varchar(100) NOT NULL,
  `fechacompra` date NOT NULL,
  `estadoprestamo` varchar(45) NOT NULL,
  `estadoequipo` varchar(45) NOT NULL,
  `categoriaid` int(11) NOT NULL,
  PRIMARY KEY (`idequipo`),
  KEY `FK_equipo_categoria` (`categoriaid`),
  CONSTRAINT `FK_equipo_categoria` FOREIGN KEY (`categoriaid`) REFERENCES `categoria` (`idcategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `equipo` VALUES (1,"QQQQ",333,"FFFFF","DDDD",1,"LABORATORIO 1","2019-08-21","D","A",4),
(2,"COMPRA",2343,"EPSON","FDFDF",1,"LABORATORIO 1","2019-08-13","O","A",2),
(3,"BBBB",753424,"WQEQWE","345FFFF",3,"LABORATORIO 1","2019-08-02","O","A",1);


DROP TABLE IF EXISTS `persona`;

CREATE TABLE `persona` (
  `idpersona` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(11) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(500) NOT NULL,
  `telefono` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `cargo` varchar(45) NOT NULL,
  `rol` varchar(45) NOT NULL,
  `estadopersona` varchar(45) NOT NULL,
  PRIMARY KEY (`idpersona`,`cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `persona` VALUES (1,1105153801,"CORREA VASQUEZ","SANTIAGO FERNANDO","LOJA",2103991,"santyfercova33@gmail.com","DOCENTE","ADMIN","A"),
(2,1150314183,"AGUILAR CABRERA","NATHALY DEL CISNE","LOJA",1234,"nathy@gmail.com","DOCENTE","ADMIN","A"),
(3,2147483647,"DDD","SSSS","CCCCC",99999,"mmmm@gmail.com","DOCENTE","PERSONA","A"),
(4,1104334634,"MENDOZA","SILVANA","LOJA",11111,"silvana@gmail.com","DOCENTE","ADMIN","A");


DROP TABLE IF EXISTS `prestamo`;

CREATE TABLE `prestamo` (
  `idprestamo` int(11) NOT NULL AUTO_INCREMENT,
  `persona` int(11) NOT NULL,
  `apellidoper` varchar(100) NOT NULL,
  `nombreper` varchar(100) NOT NULL,
  `fechaprestamo` date NOT NULL,
  `estadoprestamo` varchar(45) NOT NULL,
  `idper` int(11) NOT NULL,
  PRIMARY KEY (`idprestamo`),
  KEY `FK_prestamo_persona` (`idper`),
  CONSTRAINT `FK_prestamo_persona` FOREIGN KEY (`idper`) REFERENCES `persona` (`idpersona`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `prestamo` VALUES (1,2147483647,"DDD","SSSS","2019-09-03","A",3);


SET foreign_key_checks = 1;
